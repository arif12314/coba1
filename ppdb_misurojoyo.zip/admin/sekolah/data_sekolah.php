<?php
	$sql = $koneksi->query("select * from tb_sekolah");
	while ($data= $sql->fetch_assoc()) {
	$id_sek=$data['id_sekolah'];
	$nama=$data['nama_sekolah'];
	$alamat=$data['alamat_sekolah'];
	$akreditasi=$data['akreditasi'];
	}
?>


<div class="card card-primary">
	<div class="card-header">
		<h3 class="card-title">
			<i class="fa fa-home"></i> Data Sekolah
		</h3>
		<div class="card-tools">
		</div>
	</div>
	<div class="card-body p-1">
		<table class="table" border="1">
			<tbody>
				<tr>
					<td>
						<b>Nama Sekolah</b>
					</td>
					<td>
						<?php echo $nama; ?>

					</td>
				</tr>
				<tr>
					<td>
						<b>Alamat Sekolah</b>
					</td>
					<td>
						<?php echo $alamat; ?>
					</td>
				</tr>
				<tr>
					<td>
						<b>Akreditasi Sekolah</b>
					</td>
					<td>
						<?php echo $akreditasi; ?>
					</td>
				</tr>
			</tbody>
		</table>
		<div class="card-footer">
			<a href="?page=edit-sekolah&kode=<?php echo $id_sek; ?>" title="Ubah" class="btn btn-warning">
				Ubah Data
			</a>
		</div>
	</div>
</div>