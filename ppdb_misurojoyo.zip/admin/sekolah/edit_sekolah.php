<?php

    if(isset($_GET['kode'])){
        $sql_cek = "SELECT * FROM tb_sekolah WHERE id_sekolah='".$_GET['kode']."'";
        $query_cek = mysqli_query($koneksi, $sql_cek);
        $data_cek = mysqli_fetch_array($query_cek,MYSQLI_BOTH);
    }
?>

<div class="card card-warning">
	<div class="card-header">
		<h3 class="card-title">
			<i class="fa fa-edit"></i> Ubah Data</h3>
	</div>
	<form action="" method="post" enctype="multipart/form-data">
		<div class="card-body">

			<input type='hidden' class="form-control" name="id_sekolah" value="<?php echo $data_cek['id_sekolah']; ?>"
			 readonly/>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">Nama Sekolah</label>
				<div class="col-sm-5">
					<input type="text" class="form-control" id="nama_sekolah" name="nama_sekolah" value="<?php echo $data_cek['nama_sekolah']; ?>"
					/>
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">Alamat</label>
				<div class="col-sm-9">
					<input type="text" class="form-control" id="alamat_sekolah" name="alamat_sekolah" value="<?php echo $data_cek['alamat_sekolah']; ?>"
					/>
				</div>
			</div>

			<div class="form-group row">
				<label class="col-sm-2 col-form-label">Akreditasi Sekolah</label>
				<div class="col-sm-3">
					<input type="text" class="form-control" id="akreditasi" name="akreditasi" value="<?php echo $data_cek['akreditasi']; ?>"
					/>
				</div>
			</div>
		</div>

		<div class="card-footer">
			<input type="submit" name="Ubah" value="Simpan" class="btn btn-warning">
			<a href="?page=data-sekolah" title="Kembali" class="btn btn-secondary">Batal</a>
		</div>
	</form>
</div>


<?php

    if (isset ($_POST['Ubah'])){
    $sql_ubah = "UPDATE tb_sekolah SET
        nama_sekolah='".$_POST['nama_sekolah']."',
        alamat_sekolah='".$_POST['alamat_sekolah']."',
        akreditasi='".$_POST['akreditasi']."'
        WHERE id_sekolah='".$_POST['id_sekolah']."'";
    $query_ubah = mysqli_query($koneksi, $sql_ubah);
    mysqli_close($koneksi);

    if ($query_ubah) {
        echo "<script>
      Swal.fire({title: 'Ubah Data Berhasil',text: '',icon: 'success',confirmButtonText: 'OK'
      }).then((result) => {if (result.value)
        {window.location = 'index.php?page=data-sekolah';
        }
      })</script>";
      }else{
      echo "<script>
      Swal.fire({title: 'Ubah Data Gagal',text: '',icon: 'error',confirmButtonText: 'OK'
      }).then((result) => {if (result.value)
        {window.location = 'index.php?page=data-sekolah';
        }
      })</script>";
    }}
?>
<!--end -->