<?php
$koneksi = new mysqli ("sql.freedb.tech","freedb_ppdb_misurojoyouser","n97%?VmDnPuC?tf","freedb_ppdb_misurojoyo");
?>

<!-- END CODE -->