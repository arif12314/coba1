<?php
	$sql = $koneksi->query("select * from tb_tahun where status='Aktif'");
	while ($data= $sql->fetch_assoc()) {
	$tahun=$data['id_tahun'];
	}
?>

<div class="container">
	<!-- Page Heading/Breadcrumbs -->
	<br>
	<br>
	<!-- Intro Content -->
	<div class="row">
		<div class="col-lg-6">
			<h3>Penerimaan Peserta Didik Baru Tahun
				<?= $tahun; ?>
			</h3>
			<p style="text-align:justify">Penerimaan peserta didik baru secara ONLINE,
				<br>Bapak atau Ibu orang tua calon peserta didik baru dapat mendaftarkan putra dan putrinya sebagai peserta didik di MI MA'ARIF GENTAN SUROJOYO
				kami secara online. Sistem akan merekap secara otomatis data peserta didik baru yang di input melalui form pendaftaran.
			</p>
			<p style="text-align:justify">
				<h4>SYARAT PENDAFTARAN</h4>
				- Mengisi Formulir Online
				<a href="?page=modul-register">
					<u>Disini</u>
				</a>
				<br> - FC Akta Kelahiran
				<br> - FC Kartu Keluarga
				<br> - FC KTP Orang Tua
			</p>

		</div>
	</div>
	<!-- /.row -->
	<br>
	<div class="row">
		<div class="col-lg-12 mb-4">
			<div class="card h-100">
				<h4 class="card-header">Cek Pendaftaran</h4>
				<div class="card-body">

					<form action="?page=modul-print" method="POST">
						<div class="form-group">
							<label>Masukan NIK Untuk Melihat Formulir Pendaftaran</label>
							<input type="text" name="nik" class="form-control" placeholder="Masukkan NIK disini" required>
						</div>

						<div class="form-group">
							<input type="submit" name="Cek" value="CEK PENDAFTARAN" class="btn btn-primary">
						</div>
					</form>
				</div>
				<div class="card-footer">
				</div>
			</div>
		</div>
	</div>
	<!-- Team Members -->
	<h4>login admin dan petugas</h4>

	<div class="row">
		<div class="col-lg-4 mb-4">
			<div class="card h-100 text-center">
				<img src="landing/vendor/avatar.png" width="100%" />
				<div class="card-body">
					<h4 class="card-title">PENGELOLA PPDB</h4>
					<p class="card-text">- admin
						<br>-  petugas
				</div>
				<div class="card-footer">
					<a href="login.php">login pengguna</a>
				</div>
			</div>
		</div>
	</div>
	<!-- /.row -->
</div>
<!--END -->