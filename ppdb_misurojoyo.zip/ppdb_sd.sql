-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Jan 2021 pada 19.36
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ppdb_sd`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pendaftaran`
--

CREATE TABLE `tb_pendaftaran` (
  `id_daftar` varchar(50) NOT NULL,
  `nama_peserta` varchar(40) NOT NULL,
  `nik` varchar(20) NOT NULL,
  `tempat_lh` varchar(20) NOT NULL,
  `tgl_lh` date NOT NULL,
  `jekel` enum('Laki-laki','Perempuan') NOT NULL,
  `agama` varchar(15) NOT NULL,
  `alamat` text NOT NULL,
  `anak_ke` int(11) NOT NULL,
  `jml_saudara` int(11) NOT NULL,
  `no_kk` varchar(20) NOT NULL,
  `nama_ayah` varchar(20) NOT NULL,
  `kerja_ayah` varchar(20) NOT NULL,
  `nama_ibu` varchar(20) NOT NULL,
  `kerja_ibu` varchar(20) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `berkas` varchar(10) NOT NULL DEFAULT 'Belum',
  `waktu_daftar` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `th_ajaran` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pendaftaran`
--

INSERT INTO `tb_pendaftaran` (`id_daftar`, `nama_peserta`, `nik`, `tempat_lh`, `tgl_lh`, `jekel`, `agama`, `alamat`, `anak_ke`, `jml_saudara`, `no_kk`, `nama_ayah`, `kerja_ayah`, `nama_ibu`, `kerja_ibu`, `no_hp`, `berkas`, `waktu_daftar`, `th_ajaran`) VALUES
('0a360186-f68b-470f-bf30-a835042c47c9', 'M. Yusron', '1239871', 'Kudus', '2021-01-28', 'Laki-laki', 'Islam', 'Ds. Lokajaya Kudus', 2, 3, '445667', 'Bahrudin', 'PNS', 'Mia Yohana', 'Pedagang', '089987789090', 'Sudah', '2021-01-28 01:10:29', '2021/2022'),
('19e25450-1a9c-4350-ad31-f1a9a43984ad', 'M. Yusuf', '1234567', 'Kudus', '2021-01-07', 'Laki-laki', 'Kristen', 'Kudus', 2, 2, '8901kk', 'Sudadi', 'Nelayan', 'Sumami', 'Pedagang', '089987789098', 'Belum', '2021-01-27 17:16:01', '2021/2022'),
('7e65eea1-5fed-4bfb-a816-bb243ed38634', 'Sulaiman', '1243123', 'Semarang', '2021-01-01', 'Laki-laki', 'Islam', 'Semarang Raya', 2, 2, '123000000000003211', 'Bejo', 'Petani', 'Sariyem', 'petani', '089987789012', 'Belum', '2021-01-28 00:48:40', '2021/2022');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pengguna`
--

CREATE TABLE `tb_pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `nama_pengguna` varchar(40) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `level` enum('Administrator','Petugas') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pengguna`
--

INSERT INTO `tb_pengguna` (`id_pengguna`, `nama_pengguna`, `username`, `password`, `level`) VALUES
(1, 'Zainal Arifin', 'admin', '1', 'Administrator'),
(2, 'Slamet', 'petugas', '1', 'Petugas');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_sekolah`
--

CREATE TABLE `tb_sekolah` (
  `id_sekolah` int(11) NOT NULL,
  `nama_sekolah` varchar(40) NOT NULL,
  `alamat_sekolah` text NOT NULL,
  `akreditasi` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_sekolah`
--

INSERT INTO `tb_sekolah` (`id_sekolah`, `nama_sekolah`, `alamat_sekolah`, `akreditasi`) VALUES
(123, 'SD NEGRI 01 SURABAYA', 'Indonesia', 'A');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_sesi`
--

CREATE TABLE `tb_sesi` (
  `id_sesi` int(11) NOT NULL,
  `sesi` varchar(30) NOT NULL,
  `tgl_awal` date NOT NULL,
  `tgl_akhir` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_sesi`
--

INSERT INTO `tb_sesi` (`id_sesi`, `sesi`, `tgl_awal`, `tgl_akhir`) VALUES
(1, 'Periode 1', '2021-01-01', '2021-02-27');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_tahun`
--

CREATE TABLE `tb_tahun` (
  `id_tahun` varchar(10) NOT NULL,
  `t_ajaran` varchar(40) NOT NULL,
  `status` enum('Aktif','Non Aktif') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_tahun`
--

INSERT INTO `tb_tahun` (`id_tahun`, `t_ajaran`, `status`) VALUES
('2021/2022', 'Tahun Ajaran 2021/2022', 'Aktif');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_pendaftaran`
--
ALTER TABLE `tb_pendaftaran`
  ADD PRIMARY KEY (`id_daftar`);

--
-- Indeks untuk tabel `tb_pengguna`
--
ALTER TABLE `tb_pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indeks untuk tabel `tb_sekolah`
--
ALTER TABLE `tb_sekolah`
  ADD PRIMARY KEY (`id_sekolah`);

--
-- Indeks untuk tabel `tb_sesi`
--
ALTER TABLE `tb_sesi`
  ADD PRIMARY KEY (`id_sesi`);

--
-- Indeks untuk tabel `tb_tahun`
--
ALTER TABLE `tb_tahun`
  ADD PRIMARY KEY (`id_tahun`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_pengguna`
--
ALTER TABLE `tb_pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tb_sekolah`
--
ALTER TABLE `tb_sekolah`
  MODIFY `id_sekolah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT untuk tabel `tb_sesi`
--
ALTER TABLE `tb_sesi`
  MODIFY `id_sesi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
